declare module 'wav-encoder';
